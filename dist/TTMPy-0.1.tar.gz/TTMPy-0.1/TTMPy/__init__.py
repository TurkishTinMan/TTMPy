def TestTTMPy():
    return (u'Funziona!!!')
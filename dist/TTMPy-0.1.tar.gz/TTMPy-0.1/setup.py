from setuptools import setup

setup(name='TTMPy',
      version='0.1',
      description='toolbelt',
      url='https://github.com/TurkishTinMan/TTMPy',
      author='TurkishTinMan',
      author_email='riccardo.salladini@gmail.com',
      license='CC0',
      packages=['TTMPy'],
      zip_safe=False)